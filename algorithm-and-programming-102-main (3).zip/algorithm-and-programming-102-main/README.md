# Algorithm and Programming 102

- Course repository for weekly lecture notes, code snippets, and class discussion stories.
- The repository grows every week in a predictable structure.

## Goal of This Repo
- Keep all curriculum material in one place.
- Give students short, practical algorithm/data-structure examples.
- Make weekly teaching content easy to follow and update.

## Repository Structure
- `weeks/week-XX/`
  - `README.md` -> lecture notes for that week
  - `interactive.html` -> visualization of the topic
  - `src/` -> in-class code snippets

## Current Weeks
- `weeks/week-01`
  - Topics: Stack, Queue, Singly Linked List
- `weeks/week-02`
  - Topics: Trees, Binary Search Trees (BST)
- `weeks/week-03`
  - Topics: Linear Search, Binary Search, Jump Search
- `weeks/week-04`
  - Topics: Graph Basics, BFS, DFS, Connected Components, SCC
- `weeks/week-05`
  - Topics: Bubble Sort, Selection Sort, Insertion Sort
- `weeks/week-06`
  - Topics: Divide and Conquer, Merge Sort, Quick Sort
- `weeks/week-08`
  - Topics: Weighted Graphs, Dijkstra's Algorithm, Shortest Paths
- `weeks/week-07`
  - Topics: Greedy Algorithms, Activity Selection, Coin Change, Fractional Knapsack

## How Students Should Use This Repo
- Start from the current week folder in `weeks/`.
- Read that week's `README.md` first (concepts, workflows, homework).
- Open the files in `src/` and review code line by line.

## Quick Run Examples
- Week 01:
  - `python3 -i weeks/week-01/src/1-stack.py`
  - `python3 -i weeks/week-01/src/2-queue.py`
  - `python3 -i weeks/week-01/src/3-linked_list.py`
- Week 02:
  - `python3 -i weeks/week-02/src/1-trees.py`
  - `python3 -i weeks/week-02/src/2-binary_search_tree.py`
- Week 03:
  - `python3 -i weeks/week-03/src/1-linear_search.py`
  - `python3 -i weeks/week-03/src/2-binary_search.py`
  - `python3 -i weeks/week-03/src/3-jump_search.py`
- Week 04:
  - `python3 -i weeks/week-04/src/1-graph_basics.py`
  - `python3 -i weeks/week-04/src/2-bfs.py`
  - `python3 -i weeks/week-04/src/3-dfs.py`
- Week 05:
  - `python3 -i weeks/week-05/src/1-bubble_sort.py`
  - `python3 -i weeks/week-05/src/2-selection_sort.py`
  - `python3 -i weeks/week-05/src/3-insertion_sort.py`
- Week 06:
  - `python3 -i weeks/week-06/src/1-merge_sort.py`
  - `python3 -i weeks/week-06/src/2-quick_sort.py`
- Week 08:
  - `python3 -i weeks/week-08/src/1-weighted_graph_basics.py`
  - `python3 -i weeks/week-08/src/2-dijkstra.py`
  - `python3 -i weeks/week-08/src/3-shortest_path_reconstruction.py`
- Week 07:
  - `python3 -i weeks/week-07/src/1-activity_selection.py`
  - `python3 -i weeks/week-07/src/2-coin_change.py`
  - `python3 -i weeks/week-07/src/3-fractional_knapsack.py`

## Review Materials
- `weeks/recap-weeks-01-08.html`
  - Interactive recap page for Weeks 01 through 08
